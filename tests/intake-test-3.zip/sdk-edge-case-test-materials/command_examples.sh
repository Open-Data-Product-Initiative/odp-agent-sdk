#!/usr/bin/env bash
set -euo pipefail

# Inspect intake only. Should not call an LLM.
open-data-products portfolio intake --json   --objectives sources/objectives/   --use-cases sources/use-cases/   --signals sources/signals/   --products sources/products/   > intake-edge-cases.json

# Run build if a test provider or local mock is configured.
open-data-products portfolio build   --objectives sources/objectives/   --use-cases sources/use-cases/   --signals sources/signals/   --products sources/products/   --output portfolio-edge-cases/
