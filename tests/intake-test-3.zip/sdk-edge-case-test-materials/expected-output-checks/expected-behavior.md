# Expected Behavior Checks

This package is not a normal happy-path intake pack. It is meant to break weak assumptions.

## Detection and parser validation

- Do not trust extensions alone.
- Reject, reclassify, or warn when content signatures contradict file extensions.
- Corrupt OOXML files should not stop the whole command.
- Detection fields should include detected type, detection method, confidence, checksum, and warnings.

## Encoding and text cleanup

- UTF-8 BOM should not appear as content.
- Latin-1 text should either decode correctly or warn clearly.
- Null bytes and control characters should be removed or normalized before prompt rendering.
- Multilingual text should survive extraction without broken glyphs.

## Safe defaults

- DOCX headers, footers, comments, tracked changes, and embedded files should not be extracted by default.
- PPTX hidden slides, speaker notes, and image-only text should not be extracted by default.
- XLSX hidden sheets should not be extracted by default.
- Email attachments should not be extracted by default.
- Image-only PDFs should require OCR or vision support.

## Reporting

- Warning-only and skipped files must appear in default JSON output.
- A single bad file must not stop remaining lane sources.
- Duplicate content must preserve lane assignment.
- Nested folder behavior must be explicit.
