# SDK Edge Case Intake Test Materials

This is the third regression fixture pack for SDK source-document intake.

It focuses on defensive behavior rather than normal business content. Use it after the mixed-format pack and the long-content pack.

## What this pack tests

- Empty files and whitespace-only files
- UTF-8 BOM, Latin-1, multilingual text, emoji, and control characters
- Weird filenames, uppercase extensions, spaces, brackets, and many dots
- Misleading extensions and parser-validation conflicts
- Corrupt Office, PowerPoint, PDF, and spreadsheet files
- Blank but valid documents
- DOCX header and footer content that should not be extracted by default
- PPTX hidden slide text that should not be extracted by default
- Image-only slide content that should require OCR or vision support
- Multipart emails, malformed email headers, forwarded history, attachments, empty messages, and MSG warning-only handling
- Text PDF, image-only PDF, password-protected PDF, and zero-byte PDF
- XLSX visible sheets, hidden sheets, sparse sheets, corrupt workbooks, and CSV encoding quirks
- Duplicate content across lanes
- Nested folder behavior

## Main command

Run from this folder:

```bash
open-data-products portfolio intake --json   --objectives sources/objectives/   --use-cases sources/use-cases/   --signals sources/signals/   --products sources/products/   > intake-edge-cases.json
```

## Regression goal

The command should complete. Bad files should become warnings, not fatal workflow failures. Every warning-only or skipped file should appear in JSON output with enough metadata to debug the issue.
