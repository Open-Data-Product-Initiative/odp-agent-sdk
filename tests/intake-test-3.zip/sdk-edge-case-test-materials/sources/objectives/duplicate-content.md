# Duplicate source text

Same content appears in two lanes. Lane assignment must still be preserved.
