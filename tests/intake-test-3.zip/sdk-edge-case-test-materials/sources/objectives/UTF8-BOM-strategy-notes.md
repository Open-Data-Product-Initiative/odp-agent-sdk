﻿# Strategic objective with BOM

Reduce duplicate reporting across entities.
