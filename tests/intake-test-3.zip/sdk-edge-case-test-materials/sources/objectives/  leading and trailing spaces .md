# Weird filename

Filename spacing should not break source paths.
