# Multilingual objective

Arabic: تحسين جودة الخدمات الحكومية.
Vietnamese: Nâng cao khả năng phát hiện nhu cầu dữ liệu.
Finnish: Päätöksenteko tarvitsee parempaa tilannekuvaa.
Emoji check: ✅ should not break extraction.
