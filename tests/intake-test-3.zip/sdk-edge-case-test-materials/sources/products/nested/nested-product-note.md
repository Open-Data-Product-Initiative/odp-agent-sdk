# Nested product note

Behavior should be explicit: recursively included or warning/skipped.
