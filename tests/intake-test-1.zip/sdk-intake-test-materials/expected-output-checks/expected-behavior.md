# Expected Behavior

## Supported extraction

The SDK should extract useful text from:

- `quarterly-objectives.md`
- `strategy-priorities.pptx`
- `strategy-priorities-no-extension`, detected as PPTX from OOXML container metadata
- `board-objectives-text-pdf.pdf`, as text PDF
- `customer-service-workshop.docx`
- `teams-transcript.txt`
- `stakeholder-request.eml`
- `signal-inventory.csv`
- `kpi-notes.xlsx`
- `product-ideas.txt`
- `product-notes.json`

## Warning or skip behavior

The SDK should warn or skip:

- `misleading-office-file.docx`, because the extension says DOCX but the content is plain text
- `outlook-request.msg`, because Outlook MSG is warning-only in the base SDK
- `scanned-kpi-note-image-only.pdf`, because it is image-only and needs OCR or vision
- `product-whiteboard.jpg`, because image extraction is warning-only unless enabled
- `product-sketch.png`, because image extraction is warning-only unless enabled

## Privacy masking

The email fixture contains:

- `Anna Smith`
- `anna.smith@example-customer.com`
- `+971 50 123 4567`
- `Example Customer Group`

LLM-backed portfolio generation should mask clear personal data before prompt assembly when `portfolio.privacy.obfuscatePersonalData` is true.

## Lane preservation

Files should stay in the lane where they were placed. The same type of document should not be moved automatically between objectives, use cases, signals, and products.

## Prompt control

The long transcript should trigger size estimation and deterministic chunking when needed. Extracted text should not be silently truncated before an LLM call.
