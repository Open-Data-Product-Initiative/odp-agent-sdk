# SDK Intake Test Materials

This package tests the fresh SDK portfolio source-document intake implementation.

It contains mixed source files under the normal portfolio lane folders:

- `sources/objectives/`
- `sources/use-cases/`
- `sources/signals/`
- `sources/products/`

Run with:

```bash
open-data-products portfolio intake --json   --objectives sources/objectives/   --use-cases sources/use-cases/   --signals sources/signals/   --products sources/products/   > intake-report.json
```

Then run portfolio build when the intake report looks correct:

```bash
open-data-products portfolio build   --objectives sources/objectives/   --use-cases sources/use-cases/   --signals sources/signals/   --products sources/products/   --output portfolio-test-output/
```

The material is synthetic. It includes clear personal data patterns so privacy masking can be tested safely.
