# Expected Long Content Behavior

The SDK should:

- Extract all supported long source files into normalized source records.
- Preserve lane assignment from folders.
- Estimate size before LLM use.
- Split long records into deterministic chunks.
- Preserve stable source unit IDs and chunk IDs.
- Run privacy obfuscation before chunking and reduction.
- Keep repeated identifiers mapped to stable placeholders inside one command run.
- Report chunk counts, omitted chunk counts, reduction method, warnings, and prompt budget decisions.
- Avoid silent truncation before an LLM call.
- Avoid extracting EML attachments by default, but report attachment presence.
- Prefer current message text over quoted reply history when trimming is available.
- Warn when quoted history cannot be confidently separated.
