# Use case note 5

Need: recurring visibility into service issue category 5.

Stakeholder: Fatima Al Mansoori, fatima.almansoori@example-gov.test.

Constraint: source quality differs by entity. Expected value: reduce manual follow-up and improve prioritization.
