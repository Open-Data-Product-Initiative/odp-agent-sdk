# SDK Long Content Intake Test Materials

This pack is focused on long content behavior in portfolio source-document intake.
It is not a replacement for the mixed-format intake regression pack. It targets the specific risk that long DOCX files, long email threads, transcripts, and many small files can overflow prompt budgets, get silently truncated, lose source boundaries, or break privacy masking consistency.

## What this pack tests

- Long DOCX files with headings and natural chunk boundaries.
- Long DOCX files without headings, forcing paragraph-based chunking.
- DOCX files with long tables, testing row-group extraction and reduction.
- Long EML threads with current message, quoted history, signatures, and repeated recipients.
- EML messages with attachments that should be listed but not extracted by default.
- Repeated personal data across documents and emails, testing stable placeholders.
- Long transcript text with speaker turns, decisions, questions, requirements, and actions.
- Many small files in one lane, testing lane-level budget pressure.

## Suggested commands

```bash
open-data-products portfolio intake --json \
  --objectives sources/objectives/ \
  --use-cases sources/use-cases/ \
  --signals sources/signals/ \
  --products sources/products/
```

```bash
open-data-products portfolio build \
  --objectives sources/objectives/ \
  --use-cases sources/use-cases/ \
  --signals sources/signals/ \
  --products sources/products/ \
  --output portfolio-long-content-test/
```

## Pass criteria

The SDK should not silently truncate long content before an LLM call. It should extract, estimate size, chunk deterministically, reduce when needed, and report what happened. The report should preserve source path, lane, unit IDs, chunk counts, omitted chunk counts, warning messages, privacy replacement counts, and context-budget decisions.
