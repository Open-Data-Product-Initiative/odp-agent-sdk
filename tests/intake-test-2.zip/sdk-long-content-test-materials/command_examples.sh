#!/usr/bin/env bash
set -euo pipefail

open-data-products portfolio intake --json \
  --objectives sources/objectives/ \
  --use-cases sources/use-cases/ \
  --signals sources/signals/ \
  --products sources/products/ \
  > intake-long-content.json

open-data-products portfolio build \
  --objectives sources/objectives/ \
  --use-cases sources/use-cases/ \
  --signals sources/signals/ \
  --products sources/products/ \
  --output portfolio-long-content-test/
